__alls__ = ["analysis_market_data",
            "graphic_interface",
            "stock_market_data"]

